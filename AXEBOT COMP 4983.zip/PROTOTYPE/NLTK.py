# PRINCEDEEP SINGH
# 100153194
# Capstone Project 
# Axebot Prototype


import nltk
import numpy as np
print(np.True_)
nltk.download('punkt')
from nltk.stem.porter import PorterStemmer
stemmer = PorterStemmer()

## NATRUAL LANGUAGE PROCESSING CODE TO SIMPLIFY USER INPUT AND MATCH IT WITH THE DATASET TO PROVIDE ACCURATE RESPONSE WHICH IS HANDLED BY BOT_TRAINER CODE!!!
##     The user'sentence must be processed into three forms:
##     tokenizing the sentence( splitting it into array)
##     stemming the word ( finding one similar pattern of the word ,which will be the root word)
##     simplyfing the sentence into a bag of words ( binary form to depict that the given word is identifiable or not)

#### TOKENIZER #################################
def tokenize(sentence):
    return nltk.word_tokenize(sentence)

#### STEMMER ##############################################################
## LEMMATIZER ALSO WORKS FINE BUT STEMMER IS MORE COMPATIBLE ##############
def stem(word):
    return stemmer.stem(word.lower())

##### BAG OF WORDS ##############################
def bag_of_words(tokenized_sentence, data_words):
    tokenized_sentence = [stem(var) for var in tokenized_sentence]
    bag = np.zeros(len(data_words),dtype=np.float32)
    for i , var in enumerate(data_words):
        if var in tokenized_sentence:
            bag[i] = 1.0
    return bag



