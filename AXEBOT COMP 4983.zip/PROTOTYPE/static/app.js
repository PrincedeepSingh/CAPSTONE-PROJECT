/////javascript class to define the frontend elements to depict a chatbot in a stylish way
class Chatbox {
    constructor() {
        this.args = {
            openButton: document.querySelector('.chatbox__button'),
            chatBox: document.querySelector('.chatbox__support'),
            sendButton: document.querySelector('.send__button')}
this.state = false;this.messages = [];}

////  using the constructors to define open , close , send text and so on.......
display() {
        const {openButton, chatBox, sendButton} = this.args;
        openButton.addEventListener('click', () => this.toggleState(chatBox))
        sendButton.addEventListener('click', () => this.onSendButton(chatBox))
        const node = chatBox.querySelector('input');
        // to minimize and maximize the chatbot by dragging the dialogue box
        let m_pos;const BORDER_SIZE = 4;
        function resize(e){
        const dx = m_pos - e.x;m_pos = e.x;
        chatBox.style.width = (parseInt(getComputedStyle(chatBox, '').width) + dx) + "px";}
        chatBox.addEventListener("mousedown", function(e){
        if (e.offsetX < BORDER_SIZE) {m_pos = e.x;
        node.addEventListener("mousemove", resize, false);}
}, false);
node.addEventListener("mouseup", function(){
node.removeEventListener("mousemove", resize, false);
}, false);
        node.addEventListener("keyup", ({key}) => {
            if (key === "Enter") {this.onSendButton(chatBox)}
        })}

////////// very front   , the button from where the user will start chatting ////////////////////////////////
    toggleState(chatbox) {
        this.state = !this.state;
        if(this.state) {chatbox.classList.add('chatbox--active')} else {chatbox.classList.remove('chatbox--active')}}

//////////// when the user will send message , the message will be fetched by the backend //////////////////
    onSendButton(chatbox) {
        var textField = chatbox.querySelector('input');
        let text1 = textField.value
        if (text1 === "") {
            return;
        }
        let msg1 = { name: "you", message: text1 }
        this.messages.push(msg1);
///////////this is where the magic happens , fetching the response and posting it to the output ?///////////
        fetch('/post', {
            method: 'POST',
            body: JSON.stringify({ message: text1 }),
            mode: 'cors',
            headers: {'Content-Type': 'application/json'},
          })// throwing the request to the feed 
          .then(response => response.json())
          .then(response => {
            let msg2 = { name: "Axebot", message: response.answer };
            this.messages.push(msg2);
            this.updateChatText(chatbox)
            textField.value = ''
        }).catch((error) => { // error handling
        console.error('Error:', error);
            this.updateChatText(chatbox)
            textField.value = ''
          });
    }
//////// this actually displays the ongoing chat on//////////////////// 
    updateChatText(chatbox) {
        var html = '';
        this.messages.slice().reverse().forEach(function(item, index) {
            if (item.name === "Axebot"){html += '<div class="messages__item messages__item--visitor">' + item.message + '</div>'}
            else{html += '<div class="messages__item messages__item--operator">' + item.message + '</div>'}});
        const chatmessage = chatbox.querySelector('.chatbox__messages');
        chatmessage.innerHTML = html;
    }
}


const chatbox = new Chatbox();
chatbox.display();