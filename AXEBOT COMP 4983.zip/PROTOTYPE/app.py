# PRINCEDEEP SINGH
# 100153194
# Capstone Project 
# Axebot Prototype

import json
from flask import Flask, jsonify, render_template, request
from werkzeug.exceptions import HTTPException
from ChatBot import get_response
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
app = Flask(__name__)
app.static_folder = 'static'
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#

# get request from frontend
@app.route("/",methods=["GET"])
def base():
    return render_template("base.html")

## return with a response , making a POST request 
@app.route("/post",methods=["POST"])
def post():
    text = request.get_json().get("message")  
    response = get_response(text)
    message = {"answer":response}
    return jsonify(message)

# RUN APP
if __name__ == "__main__":
    app.run()

