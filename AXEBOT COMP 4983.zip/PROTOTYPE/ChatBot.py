# PRINCEDEEP SINGH
# 100153194
# Capstone Project 
# Axebot Prototype


import json
import random
import torch
from flask import Flask, jsonify, render_template, request, url_for
from bot_trainer import NeuralNet
from NLTK import bag_of_words, tokenize

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
f = open('intents.json', encoding='utf-8').read()
intents = json.loads(f)

FILE = "data.pth"
data = torch.load(FILE)
input_size = data["input_size"]
hidden_size = data["hidden_size"]
output_size = data["output_size"]
data_words= data["data_words"]
tags = data["tags"]   
model_state = data["model_state"]
## using the generated model by bot_model program 
model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)
model.eval()

## FRONT END OF THE MODEL FROM WHERE WE WILL PERFORM THE CONVERSATION ##
## this file solely can be used to run it on as a terminal version
bot_name = "Axebot"

## Response generator:
def get_response(msg):
    sentence = tokenize(msg)
    A = bag_of_words(sentence,data_words)
    A = A.reshape(1,A.shape[0])
    A= torch.from_numpy(A)
    output = model(A)
    _, predicted = torch.max(output,dim = 1)
    
    tag = tags[predicted.item()] ## class label
## pytorch softmax to preditct the possible reply
# sofmax is inbuilt function
#if the generated response is 75% similar to the user input , it will be considered accurate and will be given as an output
# change in % will result into different outcome , accuracy and can alter predictions.
    probs = torch.softmax(output, dim= 1)
    prob = probs[0][predicted.item()]
    if prob.item() > 0.75:
        for intent in intents["intents"]:
            if tag == intent["tag"]:
                return random.choice(intent['responses'])
                
    return "Sorry , i did not catch you , tell me again"

print("Model Synchronization Sucessful___________________________________")
###
###### if we want to run the bot in the bckend only we will use this #####
if __name__ == "__main__":
    print("Let's go my fellow Acadian!! ,type quit if you want to exit!!")
    while True:
       sentence = input('you: ')
       if sentence == "quit" or sentence == 'exit':
            break
       resp = get_response(sentence)
       print(resp)
       