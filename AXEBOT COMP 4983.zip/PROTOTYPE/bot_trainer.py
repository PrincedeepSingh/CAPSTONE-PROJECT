# PRINCEDEEP SINGH
# 100153194
# Capstone Project 
# Axebot Prototype

import numpy as np
import json
import torch
import torch.nn as nn
print(torch.__version__)
import random 
from torch.utils.data import Dataset, DataLoader
from NLTK import bag_of_words, tokenize, stem


## neural network class to setup linear module , basically in a form of tree data structrue  , it is an inbuilt class in library to perform neural networking!!!!

class NeuralNet(nn.Module):
   
    def __init__(self,input_size,background_size,num_classes):
        super(NeuralNet, self).__init__()
        self.l1 = nn.Linear(input_size,background_size)
        self.l2 = nn.Linear(background_size,background_size)
        self.l3 = nn.Linear(background_size,num_classes)
        self.relu = nn.ReLU()
## outer layer of nodes ( as neurons ) which carry forward an intent based communication 
    def forward(self,q):
        out = self.l1(q)
        out = self.relu(out)
        out = self.l2(out)
        out = self.l2(out)
        out = self.l3(out)

        return out
        
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
data_words = []
tags = []
zy = []
f = open('intents.json', encoding='utf-8').read()
intents = json.loads(f)
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Language processing method to train the bot , it fetches the intents data
# it breaks down the pattern by tokenizing and stemming them through the functions in NLTK.py file 

for intent in intents['intents']:
    tag = intent['tag']
    # add to tag list
    tags.append(tag)
    for pattern in intent['patterns']:
        # tokenize each word in the sentence
        w = tokenize(pattern)
        # add to our W list
        data_words.extend(w)
        # add to zy pair
        zy.append((w, tag))

#we will  ignore the possible special characters because sentence is the make source which our axebot has to understand. 
IGNOREWORDS = ['?','!']
data_words = [stem(w) for w in data_words if w not in IGNOREWORDS]
# remove duplicates and sort
data_words = sorted(set(data_words))
tags = sorted(set(tags))

print(len(zy), "patterns")
print(len(tags), "tags:", tags)
print(len(data_words), "unique stemmed W:", data_words)

z_train = []
y_train = []
for (pattern_sentence, tag) in zy:
    # X: bag of W for each pattern_sentence
    bag = bag_of_words(pattern_sentence, data_words)
    z_train.append(bag)
    # y: PyTorch CrossEntropyLoss needs only class labels
    label = tags.index(tag)
    y_train.append(label)

z_train = np.array(z_train)
y_train = np.array(y_train)


## setting parameters for bot training loader to process the accuracy 
num_of_epoch = 1000
batch_size = 8
background_size = 12
learning_rate = 0.001
input_size = len(z_train[0])
hidden_size = 8
output_size = len(tags)
print(input_size, output_size)


# Dataset algorithm to match the pattern
class BotDataSet(Dataset):

    def __init__(self):
        ### data samples for training
        self.n_samples = len(z_train)
        self.x_data = z_train
        self.y_data = y_train

    # support indexing such that dataset[i] can be used to get i-th sample
    def __getitem__(self, index):
        return self.x_data[index], self.y_data[index]

    def __len__(self):
        return self.n_samples

dataset = BotDataSet()
# Loading the big data and make loading little bit faster 
# more words in the daataset will make our axebot learn more , more data will mean a better axebot !!!!
train_loader = DataLoader(dataset=dataset,
                          batch_size=batch_size,
                          shuffle=True,
                          num_workers=0)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = NeuralNet(input_size, hidden_size, output_size).to(device)

# Loss and optimizer ( entropy loss later used by epoch )
Enloss = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

# epoch is a a machine learning term  which is specifically a neural networking method
#epoch here is a variable which defines the no. of times machine learning algorithm passes through the training dataset.
#it basically is a core method for training our axebot with the existing dataset to make the model learn and validate that the axebot is prepared to use the dataset


## num_of_epoch is the number of iterations whcih will be performed on the Model.
# training with one epoch is not enough! ( )
for epoch in range(num_of_epoch):
    for (W, labels) in train_loader:
        W = W.to(device)
        labels = labels.to(dtype=torch.long).to(device)
        outputs = model(W)
        loss = Enloss(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    if (epoch+1) % 100 == 0:
        print (f'Epoch [{epoch+1}/{num_of_epoch}], Loss: {loss.item():.4f}')
## final loss determines the accuracy , lower is better , correct predictions and how similar are these to the actual values is bascially what this chatbot is all about.
print(f'final loss: {loss.item():.4f}')

## dictionary to save the model state (data)
data = {
"model_state": model.state_dict(),
"input_size": input_size,"hidden_size": hidden_size,
"output_size": output_size,"data_words": data_words,"tags": tags}

FILE = "data.pth"
torch.save(data, FILE)
## data.pth file here is the scirpt of the trained model (axebot), this is super important for the axebot because this will be it's brain memory
print(f'Bot trained succesfully.saved to {FILE}')
